﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raiz_Enesima
{
    public partial class Form1 : Form
    {
        double radicando;
        double indice;
        double resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //valida o valor do radicando
            if(string.IsNullOrEmpty(txtRadicando.Text))
            {
                MessageBox.Show("Informe o valor do radicando");
                return;
            }
            else
            {
                lblRadicando.Text = txtRadicando.Text;
            }

            //valida o valor do indice
            if (string.IsNullOrEmpty(txtIndice.Text))
            {
                MessageBox.Show("Informe o valor do índice");
                return;
            }
            else
            {
                lblIndice.Text = txtIndice.Text;
            }

            //calcula a raiz enesima
            try
            {
                radicando = double.Parse(txtRadicando.Text);
                indice = double.Parse(txtIndice.Text);
                resultado = Math.Pow(radicando, 1 / indice);
                txtresultado.Text = resultado.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :" + ex.Message);
            }
        }

        //so numeros no textbox
        private void txtRadicando_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        //so numeros no textbox
        private void txtIndice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        //Recebe TAB e envia ENTER no formulario (KeyPreview=True)
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.SelectNextControl(this.ActiveControl, !e.Shift, true, true, true);
            }
        }
    }
}
